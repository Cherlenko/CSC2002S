import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
//import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import javax.imageio.ImageIO;

public class MedianFilterParallel 
{
    static long runTime=0;
    static long startTime=0;
   /**
    * @param file
    */
   public static void Filter(String file)
    {
        BufferedImage image = null;
        File fimage = null;
        
        String[] imageIO = file.split(" ");
        //int noThreads = Runtime.getRuntime().availableProcessors(); 
        ForkJoinPool pool = ForkJoinPool.commonPool();
       // ParallelMergeSort Merge;
        
        try{
            fimage =new File(imageIO[0]);
            image = ImageIO.read(fimage);
        }
        catch(IOException e)
        {
            extracted(e);
        }
        
        final int width=image.getWidth();
        int height=image.getHeight();
        StartTime(); //start
        for(int y=1;y<height-1;y++)
            for(int x=1;x<width-1;x++)
            {
                /**
                  reference: https://www.geeksforgeeks.org/spatial-filters-averaging-filter-and-median-filter-in-image-processing/
                  
                  Neighborhood processing in spatial domain: 
                  Here, to modify one pixel, we consider values of the immediate neighboring pixels also. 
                  For this purpose, 3X3, 5X5, 7X7 or even higher dimensions neighborhood mask can be considered. 
                **/

                int[] arrayOfSurroundingPixels = new int[9];
                arrayOfSurroundingPixels[0] = image.getRGB(x, y);
                arrayOfSurroundingPixels[1] = image.getRGB(x-1, y-1);
                arrayOfSurroundingPixels[2] = image.getRGB(x-1, y);
                arrayOfSurroundingPixels[3] = image.getRGB(x-1, y+1);
                arrayOfSurroundingPixels[4] = image.getRGB(x, y-1);
                arrayOfSurroundingPixels[5] = image.getRGB(x, y+1);
                arrayOfSurroundingPixels[6] = image.getRGB(x+1, y-1);
                arrayOfSurroundingPixels[7] = image.getRGB(x+1, y);
                arrayOfSurroundingPixels[8] = image.getRGB(x+1, y+1);
                //Arrays.parallelSort(arrayOfSurroundingPixels);
                //Merge = new ParallelMergeSort(arrayOfSurroundingPixels);
                
                pool.invoke(new ParallelMergeSort(arrayOfSurroundingPixels));  //invoking parallel sorting
                
                int pixelvalue = image.getRGB(x, y);
                int p1 = arrayOfSurroundingPixels[4];
                
                if(pixelvalue>255||pixelvalue<0)
                    image.setRGB(x, y, p1);
            }
            endTime(); //end
        try{
            int index = imageIO[1].indexOf(".");
            int length = imageIO[1].length();
            ImageIO.write(image, imageIO[1].substring(index+1,length), new File(imageIO[1])); 
        }
	     catch(IOException e)
        {
            System.out.println(e);
        }
    }

    private static void StartTime() {
        startTime =System.currentTimeMillis();
    }
    
    private static void endTime() {
        runTime = System.currentTimeMillis() - startTime;
    }

    /**
     * @param e
     */
    private static void extracted(IOException e) {
        e.printStackTrace();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
      String[] p = {"Coins1.jpeg bb.jpeg 3"};
      Filter(p[0]);
      System.out.println("Run1 took "+ runTime/ 1000.0f +" seconds");

      Filter(p[0]);
      System.out.println("Run2 took "+ runTime/ 1000.0f +" seconds");

      Filter(p[0]);
      System.out.println("Run3 took "+ runTime/ 1000.0f +" seconds");

      Filter(p[0]);
      System.out.println("Run4 took "+ runTime/ 1000.0f +" seconds");

      Filter(p[0]);
      System.out.println("Run5 took "+ runTime/ 1000.0f +" seconds");
    }
}

class ParallelMergeSort extends RecursiveAction
{
   /**
    * This class is for doing mergesort for the array of pixels, but sorting it using the ForkJoin framework
    * what it does it first break the array into chunks that are equivalent to the number of processors,
    * and every thread will mergely sort the assigned chunk array to it, after sorting it merge everything  
    */ 
    private final int[] arr;

    /**
    * @param arr
    */
   public ParallelMergeSort(int[] arr) {
        this.arr = arr;
    }

    /* (non-Javadoc)
    * @see java.util.concurrent.RecursiveAction#compute()
    */
   @Override
    public void compute() {
       if (arr.length < 2) return;
       int mid = arr.length / 2;
   
       int[] left = new int[mid];
       /**
        * System.arraycopy:
        * Copies an array from the specified source array, 
        * beginning at the specified position, to the specified position of the destination array. 
        */
       System.arraycopy(arr, 0, left, 0, mid);
   
       int[] right = new int[arr.length - mid];
       System.arraycopy(arr, mid, right, 0, arr.length - mid);
   
       INVOKE(left, right);
       merge(left, right);
    }

   /**
 * @param left
 * @param right
 */
private void INVOKE(int[] left, int[] right) {
      invokeAll(new ParallelMergeSort(left), new ParallelMergeSort(right));
   }

    /**
    * @param left
    * @param right
    */
   private void merge(int[] left, int[] right) {
       int i = 0, j = 0, k = 0;
       while (i < left.length && j < right.length) {
           if (left[i] < right[j])
               arr[k++] = left[i++];
           else
               arr[k++] = right[j++];
       }
       while (i < left.length) {
           arr[k++] = left[i++];
       }
       while (j < right.length) {
           arr[k++] = right[j++];
       }
    }

}
