import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
//import java.util.*;


/**
 * The mean filter is a simple sliding-window spatial filter that replaces 
 * the center value in the window 
 * with the average (mean) of all the pixel values in the window. 
 */
public class MeanFilterSerial{

   static long startTime = 0;
   static long runTime = 0;
   
   /**
    * @param INPUT
    */
   public static void Filter(String INPUT){
      /**
       * method to filter an image using 
       * the mean filter slidig window algorithm
       */
      String[] files = INPUT.split(" ");  //array to store input files
   
      File image = null;
      BufferedImage input = null;
      BufferedImage output = null;
           
      int windowWidth = Integer.valueOf(files[2]);     //window width for the picture
      if(windowWidth < 3 || windowWidth % 2 == 0){   //window width must be odd
         System.out.println("Error, Window size must be odd.");
      }
      
      try{
         image = new File(files[0]);  //reading file
         input = ImageIO.read(image);  //proccesing image file  
      }
      catch(IOException e){
         e.printStackTrace();
      }
      
      int Edgepixels = (windowWidth - 1)/2;  //number of edge pixels surrounding middle pixel
      int width = input.getWidth();      //width of picture
      int height = input.getHeight();    //height of picture
      int pixel;
      
      StartTime(); //start
   
      //outer nested loops to traverse over the window of pixels
      for (int y = 0; y < height; y++){
         for (int x = 0; x < width; x++){
            int redAVERAGE = 0;    //to store average of red color in pixel
            int greenAVERAGE = 0;  //to store average of green color in pixel
            int blueAVERAGE = 0;   //to store average of blue color in pixel
            
            //check for Edge pixels
            if(!((x - Edgepixels < 0) || (y - Edgepixels < 0) || (x + Edgepixels >= width) || (y + Edgepixels >= height))) {
               
               //inner loops to traverse over the edge pixels
               for  (int j = y - Edgepixels; j <= y + Edgepixels; j++){
                  for(int i = x - Edgepixels; i <= x + Edgepixels; i++){
                  
                     pixel = input.getRGB(i, j);
                     
                     int red = (pixel>>16)&0xff;
                     redAVERAGE = (redAVERAGE + red);
                     int green = (pixel>>8)&0xff;
                     greenAVERAGE = (greenAVERAGE + green);
                     int blue = pixel&0xff;
                     blueAVERAGE = blueAVERAGE + blue;
                  }
               }
               
               redAVERAGE = redAVERAGE /(windowWidth*windowWidth);   //average of red in a certain pixel
               greenAVERAGE = greenAVERAGE /(windowWidth*windowWidth);  //average of green in a certain pixel
               blueAVERAGE = blueAVERAGE /(windowWidth*windowWidth);   //average of blue in a certain pixel
               
               pixel = (redAVERAGE<<16)|(greenAVERAGE<<8)|blueAVERAGE;  //setting a smooth pixel color
               
            } else {
               pixel = input.getRGB(x, y);
            }
            input.setRGB(x, y, pixel);
         }
      }
      EndTime(); //end
     
     //writing new image to file    
      try{
         int index = files[1].indexOf(".");
         String format = files[1].substring(index+1,files[1].length());
         ImageIO.write(input, format , new File(files[1]));
      }
      catch(IOException e){
         e.printStackTrace(); 
      }        
   }
   
   public static void StartTime(){
      startTime = System.currentTimeMillis();
   }

   public static void EndTime(){
      runTime = System.currentTimeMillis() - startTime;
   }
    
   /**
    * @param args
    */
   public static void main(String[] args) {
      String[] p = {"pop.png bb.jpeg 3"};
      Filter(p[0]);
      System.out.println("Run1 took "+ runTime/ 1000.0f +" seconds");
   
      Filter(p[0]);
      System.out.println("Run2 took "+ runTime/ 1000.0f +" seconds");
   
      Filter(p[0]);
      System.out.println("Run3 took "+ runTime/ 1000.0f +" seconds");
   
      Filter(p[0]);
      System.out.println("Run4 took "+ runTime/ 1000.0f +" seconds");
   
      Filter(p[0]);
      System.out.println("Run5 took "+ runTime/ 1000.0f +" seconds");
   }
}