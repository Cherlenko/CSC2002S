import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
//import java.util.Arrays;

import javax.imageio.ImageIO;

public class MedianFilterSerial 
{
    static long startTime =0;
    static long runTime=0;
   /**
    * @param file
    */
    public static void Filter(String file)
    {
        BufferedImage image = null;
        File fimage = null;
        
        String[] imageIO = file.split(" ");
        
        try{
            fimage =new File(imageIO[0]);
            image = ImageIO.read(fimage);
        }
        catch(IOException e)
        {
            extracted(e);
        }
        
        final int width=image.getWidth();
        int height=image.getHeight();
        StartTime(); //start
        for(int y=1;y<height-1;y++)
            for(int x=1;x<width-1;x++)
            {
                /**
                  reference: https://www.geeksforgeeks.org/spatial-filters-averaging-filter-and-median-filter-in-image-processing/
                  
                  Neighborhood processing in spatial domain: 
                  Here, to modify one pixel, we consider values of the immediate neighboring pixels also. 
                  For this purpose, 3X3, 5X5, 7X7 or even higher dimensions neighborhood mask can be considered. 
                **/

                int[] arrayOfSurroundingPixels = new int[9];
                arrayOfSurroundingPixels[0] = image.getRGB(x, y);
                arrayOfSurroundingPixels[1] = image.getRGB(x-1, y-1);
                arrayOfSurroundingPixels[2] = image.getRGB(x-1, y);
                arrayOfSurroundingPixels[3] = image.getRGB(x-1, y+1);
                arrayOfSurroundingPixels[4] = image.getRGB(x, y-1);
                arrayOfSurroundingPixels[5] = image.getRGB(x, y+1);
                arrayOfSurroundingPixels[6] = image.getRGB(x+1, y-1);
                arrayOfSurroundingPixels[7] = image.getRGB(x+1, y);
                arrayOfSurroundingPixels[8] = image.getRGB(x+1, y+1);
                //Arrays.Sort(arrayOfSurroundingPixels);
                
                Sort(arrayOfSurroundingPixels);
                int pixelvalue = image.getRGB(x, y);
                int middlePixel = arrayOfSurroundingPixels[4];  //it will get the middle value of the sorted array of every 3x3 window of the picture
                
                if(pixelvalue>255||pixelvalue<0)
                    image.setRGB(x, y, middlePixel);
            }
            EndTime(); //end
        try{
            int index = imageIO[1].indexOf(".");
            int length = imageIO[1].length();
            ImageIO.write(image, imageIO[1].substring(index+1,length), new File(imageIO[1])); 
        }
	     catch(IOException e)
        {
            System.out.println(e);
        }
    }

    /**
     * @param e
     */
    private static void extracted(IOException e) {
        e.printStackTrace();
    }

    public static void StartTime(){
        startTime = System.currentTimeMillis();
    }

    public static void EndTime(){
        runTime = System.currentTimeMillis() - startTime;
    }

    public static void main(String[] args) {
        String[] p = {"Coins1.jpeg bb.jpeg 3"};
        Filter(p[0]);
        System.out.println("Run1 took "+ runTime/ 1000.0f +" seconds");
  
        Filter(p[0]);
        System.out.println("Run2 took "+ runTime/ 1000.0f +" seconds");
  
        Filter(p[0]);
        System.out.println("Run3 took "+ runTime/ 1000.0f +" seconds");
  
        Filter(p[0]);
        System.out.println("Run4 took "+ runTime/ 1000.0f +" seconds");
  
        Filter(p[0]);
        System.out.println("Run5 took "+ runTime/ 1000.0f +" seconds");
    }

    /**
     * @param nonSort
     */
   private static void Sort(int[] nonSort)
   {
      /**
       * this method will use selection sort to the array,
       * what it does is that it first creat a locator index (partitions),
       * then after it creat a tracker index, to track elements that will be
       * less than the locator index elements, and if it finds one then they swap.
      **/ 
      for(int outerloop = 0;outerloop<nonSort.length;outerloop++){
         int locator = outerloop;                 
         for(int innerloop = outerloop+1;innerloop<nonSort.length;innerloop++){
            if((nonSort[innerloop]<(nonSort[locator]))){
               locator = innerloop;
            }
         }
         //this is how to swap elements in an array
         int temp = nonSort[locator];
         nonSort[locator] = nonSort[outerloop];
         nonSort[outerloop] = temp; 
      }
   } 
}