package typingTutor;

import java.util.concurrent.atomic.AtomicBoolean;

//Thread to monitor the word that has been typed.
public class CatchWord extends Thread {
	String target;
	static AtomicBoolean done ; //REMOVE
	static AtomicBoolean pause; //REMOVE
	
	private static  FallingWord[] words; //list of words
	private static HungryWord hungryWord; 
	private static int noWords; //how many
	private static Score score; //user score
	
	CatchWord(String typedWord) {
		target=typedWord;
	}
	
	/**
	 * @param hungry
	 */
	public static void setHungryWord(HungryWord hungry) {
		hungryWord = hungry;
	}
	public static void setWords(FallingWord[] wordList) {
		words=wordList;	
		noWords = words.length;
	}
	
	public static void setScore(Score sharedScore) {
		score=sharedScore;
	}
	
	public static void setFlags(AtomicBoolean d, AtomicBoolean p) {
		done=d;
		pause=p;
	}
	
	public void run() {
		int i=0;
		while (i<noWords) {		
			while(pause.get()) {};

			//catching words with the hungry word
			if (hungryWord.matchWord(target)) {
				System.out.println(" score! hungry: " + target); // for checking
				score.caughtWord(target.length());
				break;
			}

			if (words[i].matchWord(target)) {
				FallingWord match = words[i];  // get the position of the word to compare with its duplicate
				//int j=i; //avoiding clashes with the index
				while(i<noWords){ //tranverse over the array of words
					if(words[i].matchWord(target)){ // continue to look for another match
						if(match.getY()<words[i].getY()){ //checks which word is the bottom one amongst the duplicates
							match=words[i]; //save the one that is lower on the screen
							break;
						}
					}
               //match.resetWord();
					i++;
				}
				/**
				 * we going to reset here not in falling words since we
				 * don't want to reset all the duplicates after catching 
				 * the bottom word.
				 */
				match.resetWord();
				System.out.println( " score! '" + target); //for checking
				score.caughtWord(target.length());	
				FallingWord.increaseSpeed();
				break;
			}
		   i++;
		}
		
	}	
}
