package typingTutor;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class HungryWordMover extends Thread {
    /**
     * This class is exatly implimented like the
     * WordMover class but added 
     * 
     * 1.MovingWord -instance variable from the HungryWord class type
     * 2.words -instance variable array to store all the vertically falling words
     * 3.setWords(FallingWord[] words) - mutator method to ensure encapsulation
     * 4.A modified run method to implement the horizontal movement of the 'hungry word'
     *   and also to implement an algorithm that checks if the horizontally moving word
     *   has catched a vertically moving word.
     */

    private HungryWord MovingWord;
    private AtomicBoolean done;
    private AtomicBoolean pause;
    private Score score;
    private FallingWord[] words;
    CountDownLatch startLatch; // so all can start at once

    /**
     * @param word
     */
    HungryWordMover(HungryWord word) {
        MovingWord = word;
    }

    /**
     * @param word
     * @param dict
     * @param score
     * @param startLatch
     * @param d
     * @param p
     */
    HungryWordMover(HungryWord word, WordDictionary dict, Score score,
            CountDownLatch startLatch, AtomicBoolean d, AtomicBoolean p) {
        this(word);
        this.startLatch = startLatch;
        this.score = score;
        this.done = d;
        this.pause = p;
    }

    /**
     * @param words
     */
    public void setWords(FallingWord[] words) {
        this.words = words;
    }

    /* (non-Javadoc)
     * @see java.lang.Thread#run()
     */
    public void run() {

        try {
            System.out.println(MovingWord.getWord() + " waiting to start ");
            startLatch.await();
        } catch (InterruptedException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } // wait for other threads to start
        System.out.println(MovingWord.getWord() + " started");
        while (!done.get()) {
            // animate the word
            while (!MovingWord.NotCaught() && !done.get()) {

                // If the moving word touches others words, those words must dissapear
                int i = 0;
                while(i < words.length) {
                    //why 16? is the approximate factor of where the coordinate x, y can end in the frame interface
                    int X_1 = MovingWord.getX();  //starting position
                    int X_last = MovingWord.getX() + MovingWord.getWord().length() * 16; 
                    int Y_1 = MovingWord.getY();
                    int Y_last = MovingWord.getY() + 16;

                    int X_2 = words[i].getX();
                    int X2_last = words[i].getX() + words[i].getWord().length() * 16;
                    int Y_2 = words[i].getY();
                    int Y2_last = words[i].getY() + 16;
                    
                    /**statements to check if the hungry word has catch the vertically moving words
                     * everytime the hungry word catches a vertically moving word it will it will call
                     * the missedWords method from the score class to append to the missed counter
                     * 
                     * There are actually 16 posibilities how the hungry word can catch the vertically moving words.
                     * since i have assumed the approximate factor of a position of where a word will end is 16, 
                     * there should be every statement checking for every possibility of factor 16 in the x and y direction
                    **/
                    if ((X_last >= X_2 && X_1 <= X2_last) && (Y2_last >= Y_1 && Y_2 <= Y_last)) {
                        words[i].resetWord();
                        score.missedWord();
                    } 
                    else if ((X_last >= X_2 && X_1 <= X2_last)&& (Y_last >= Y_2 && Y_1 <= Y2_last)) {
                        words[i].resetWord();
                        score.missedWord();
                    } 
                    else if ((X2_last >= X_1 && X_2 <= X_last)&& (Y2_last >= Y_1 && Y_2 <= Y_last)) {
                        words[i].resetWord();
                        score.missedWord();
                    } 
                    else if ((X2_last >= X_1 && X_2 <= X_last)&& (Y_last >= Y_2 && Y_1 <= Y2_last)) {
                        words[i].resetWord();
                        score.missedWord();
                    }
                    i++;
                }
                MovingWord.moveHorizontally(20); //move by factor of 20
                try {
                    sleep(MovingWord.getSpeed()); //make sure threads don't overlap and share same data at the same time
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                ;
                while (pause.get() && !done.get()) {};
            }
            if (!done.get() && MovingWord.NotCaught()) {
                score.missedWord();
                MovingWord.resetWord();
            }
            MovingWord.resetWord();
        }
    }

}